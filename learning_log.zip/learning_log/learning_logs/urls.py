#定义learning_logs的URL模式
#在文件夹learning_log中有默认的urls.py文件

from django.conf.urls import url
from . import views     #句点让Pyhon从当前的urls.py模块中导入视图

urlpatterns=[
    #定义主页
    url(r'^$',views.index,name='index'),
    
    ]
